print("Welcome to the tip calculator.")

total_bill = float(input("What is the total bill? $"))
percentage_tip = float(input("What percentage tip would you like to give? "))
party_size = int(input("How many people are splitting the bill? "))

tip_amount = total_bill * (percentage_tip / 100)
final_bill = total_bill + tip_amount
split_amount = final_bill / party_size

print(f"Total bill with tip is: ${final_bill:.2f}")
print(f"Tip amount is: ${tip_amount:.2f}")
print(f"Each person should pay: ${split_amount:.2f}")
