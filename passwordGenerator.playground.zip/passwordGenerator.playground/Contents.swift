import UIKit
import Foundation

func generatePassword(lenght: Int, useUppercase: Bool, useNumbers: Bool, useSpecialCharacters: Bool) -> String {
    let lowerCaseLetters = "abcdefgijklmnopqrstuvwxyz"
    var characters = lowerCaseLetters
    if useUppercase {
        characters += lowerCaseLetters.uppercased()
    }
    if useNumbers {
        characters += "0123456789"
    }
    if useSpecialCharacters {
        characters += "!@#$%^&*"
    }
    let randomCharacters = (0..<lenght).compactMap {_ in characters.randomElement()
    }
    return String(randomCharacters)
}
    
let password = generatePassword(lenght: 12, useUppercase: true, useNumbers: true, useSpecialCharacters: true)
print(password)
